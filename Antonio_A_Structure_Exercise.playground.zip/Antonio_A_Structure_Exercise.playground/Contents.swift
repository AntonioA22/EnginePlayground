import UIKit

struct engine {
    var V8 = 8
    var V6 = 6
    var V4 = 4
}
let carengine = engine()
print ("The car should have a \(carengine.V8) Cylinder engine in it")
